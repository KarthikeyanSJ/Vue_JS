<template>
    <div>
        <h5>Dude. You are not assigned to required role.</h5>
    </div>
</template>

<script>


export default {
  data () {
    return {
    }
  },
  computed: {
  },
  components: {
  }
}
</script>
